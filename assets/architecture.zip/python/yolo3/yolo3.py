# -*- coding: utf-8 -*-
"""
Class definition of YOLO_v3 style detection model on image and video
Based on https://github.com/qqwweee/keras-yolo3

JCA
Vaico
"""

import colorsys
from timeit import default_timer as timer
import logging

import numpy as np
import tensorflow as tf
from tensorflow.keras import backend as K
from tensorflow.keras.layers import Input
from tensorflow.keras.utils import multi_gpu_model
from MLgeometry.geometries.BoundBox import BoundBox
from MLgeometry.Object import Object
from MLcommon.AbcModel import AbcModel as AbcModel

from yolo3.auxfunc.model import yolo_eval, yolo_body, tiny_yolo_body
from yolo3.auxfunc.utils import letterbox_image_cv


LOGGER = logging.getLogger(__name__)


class Yolo3(AbcModel):
    _defaults = {
        #Model
        'model_anchors': [10,13,  16,30,  33,23,  30,61,  62,45,  59,119,  116,90,  156,198,  373,326],
        'model_labels': [None],
        "model_image_size" : (416, 416),
        #Prediction
        "pred_obj_thresh" : 0.3,
        "pred_iou" : 0.45,
        "pred_gpu_num" : 1,
    }

    def __init__(self, conf):
        self.anchors = np.array(conf.get('model_anchors', self._defaults['model_anchors'])).reshape(-1, 2)
        self.sess = K.get_session()
        super().__init__(**conf)# set model
        self.boxes, self.scores, self.classes = self.generate()

    def load_architecture(self):
        if not self.model_labels[0]:
            LOGGER.warning('Model does not have labels')
        num_anchors = len(self.anchors)
        num_classes = len(self.model_labels)
        is_tiny_version = num_anchors==6 # default setting

        model = tiny_yolo_body(Input(shape=(None,None,3)), num_anchors//2, num_classes) \
            if is_tiny_version else yolo_body(Input(shape=(None,None,3)), num_anchors//3, num_classes)
        assert model.layers[-1].output_shape[-1] == \
            num_anchors/len(model.output) * (num_classes + 5), \
            'Mismatch between model and given anchor and class sizes'
        self.sess.run(tf.global_variables_initializer())
        
        return model
    
    def generate(self):
        # Generate colors for drawing bounding boxes.
        hsv_tuples = [(x / len(self.model_labels), 1., 1.)
                      for x in range(len(self.model_labels))]
        self.colors = list(map(lambda x: colorsys.hsv_to_rgb(*x), hsv_tuples))
        self.colors = list(
            map(lambda x: (int(x[0] * 255), int(x[1] * 255), int(x[2] * 255)),
                self.colors))
        np.random.seed(10101)  # Fixed seed for consistent colors across runs.
        np.random.shuffle(self.colors)  # Shuffle colors to decorrelate adjacent classes.
        np.random.seed(None)  # Reset seed to default.

        # Generate output tensor targets for filtered bounding boxes.
        self.input_image_shape = K.placeholder(shape=(2, ))
        if self.pred_gpu_num>=2:
            self.model = multi_gpu_model(self.model, gpus=self.pred_gpu_num)
        boxes, scores, classes = yolo_eval(self.model.output, self.anchors,
                len(self.model_labels), self.input_image_shape,
                score_threshold=self.pred_obj_thresh, iou_threshold=self.pred_iou)
        return boxes, scores, classes

    def predict(self, image,  **param):
        start = timer()
        if self.model_image_size != (None, None):
            assert self.model_image_size[0]%32 == 0, 'Multiples of 32 required'
            assert self.model_image_size[1]%32 == 0, 'Multiples of 32 required'
            boxed_image = letterbox_image_cv(image, self.model_image_size)
            
        else:
            new_image_size = (image.width - (image.width % 32),
                              image.height - (image.height % 32))
            boxed_image = letterbox_image_cv(image, new_image_size)
    
        image_data = np.array(boxed_image, dtype='float32')
        image_data /= 255.
        image_data = np.expand_dims(image_data, 0)  # Add batch dimension.

        out_boxes, out_scores, out_classes = self.sess.run(
            [self.boxes, self.scores, self.classes],
            feed_dict={
                self.model.input: image_data,
                self.input_image_shape: [image.shape[0], image.shape[1]],
                K.learning_phase(): 0
            })

        print('Found {} boxes for {}'.format(len(out_boxes), 'img'))
        res =[]
        for i, c in reversed(list(enumerate(out_classes))):
            predicted_class = self.model_labels[c]
            box = out_boxes[i]
            score = out_scores[i]
            top, left, bottom, right = box
            top = max(0, np.floor(top + 0.5).astype('int32'))
            left = max(0, np.floor(left + 0.5).astype('int32'))
            bottom = min(image.shape[0], np.floor(bottom + 0.5).astype('int32'))
            right = min(image.shape[1], np.floor(right + 0.5).astype('int32'))
            print(predicted_class, (left, top), (right, bottom), score)
            newObj = Object(
                    BoundBox(
                        int(left),#xmin
                        int(top),#ymin
                        int(right),#xmax
                        int(bottom)),#ymax
                    str(predicted_class), 
                    float(score), 
                    subobject=None)
            res.append(newObj)
        end = timer()
        print(end - start)
        return res

    def close_session(self):
        self.sess.close()

    def train(self, train_imgs, valid_imgs, **param: 'training parameters'):
        """Predict function. Return prediction namedtuples"""
        #TODO
        # Implement training based on: https://github.com/qqwweee/keras-yolo3
        pass
